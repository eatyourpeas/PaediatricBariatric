module PatientsHelper

	
end
