class Operation < ActiveRecord::Base
  belongs_to :patient
end
