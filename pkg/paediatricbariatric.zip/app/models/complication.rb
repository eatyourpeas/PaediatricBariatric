class Complication < ActiveRecord::Base
  belongs_to :patient
end
