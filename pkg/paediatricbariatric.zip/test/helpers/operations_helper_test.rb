require 'test_helper'

class OperationsHelperTest < ActionView::TestCase
end
