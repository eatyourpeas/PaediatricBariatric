require 'test_helper'

class ComplicationsHelperTest < ActionView::TestCase
end
