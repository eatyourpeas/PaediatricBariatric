require 'test_helper'

class ComplicationsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
