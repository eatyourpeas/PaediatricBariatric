require 'test_helper'

class ComplicationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
